# selenium-testng
### A sample selenium, testng and maven project to login, load a page and add few assertions.

## Steps to run - 
- checkout this repository
- from the base directory use `mvn clean test` to run the tests
- or run `src/test/java/selenium.testng.sample.HubLoginTest` from the IDE